# Landing Page Project

###This is my first project, and I hope to be successful in using the tools that I learned to implement what is required of me in this project.

###I have added the sections via JavaScript.

###I created a function to create a link for each section.

###Modified the active class properties for both section and link.

### I appled smooth scrolling using vanilla javascript


